const mongoose = require("mongoose");

// creating a databse
mongoose.connect("mongodb://localhost:27017/Deepdream", {
// useCreateindex:false,
// useNewUrlParser:false,
// useUnifieldTopology:false
}).then(() => {
console.log("connection successful");
}).catch((error) => {
    console.log(error);
})


